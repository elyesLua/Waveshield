# WaveShield Cracked

## Prerequisite
- To install it you will need mysql-async only !

## Credit
💖 Cracked by $K"elyess FNet#1111
