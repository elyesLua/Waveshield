ConfigACS = {}

ConfigACS.ModelsLogWebhook = "a"
ConfigACS.ExplosionLogWebhook = "a"

ConfigACS.LogBanWebhook = "a" --YOUR BANS/LOGS WEBHOOK
ConfigACS.AntiVPNWebhook = "a" -- ANTIVPN WEBHOOK

ConfigACS.ServerName = "a" --YOUR SERVER NAME

ConfigACS.Version = "v1.6.4" -- DONT TOUCH THIS

ConfigACS.License = "CRACKED"